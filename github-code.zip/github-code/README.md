# DNA Sequence Comparison and Alignment System

Design and Analysis of Algorithms project by **Kavin S (711525BCS069)**, II-CSE-A, KIT – Kalaignarkarunanidhi Institute of Technology.

Algorithms: brute-force recursion, LCS by dynamic programming, Needleman–Wunsch global alignment, Hirschberg linear-space LCS.

## Files
| File | Purpose |
|---|---|
| `dna_alignment.py` | Python implementation + the five test cases from the report |
| `index.html` | Browser version (same algorithms in JavaScript) – no install needed |
| `output.txt` | Saved console output of `dna_alignment.py` |

## Run
**Python:** `python dna_alignment.py`

**Browser:** open `index.html`, or enable GitHub Pages (Settings → Pages → Deploy from branch → `main` / root) and open
`https://<your-username>.github.io/<repo-name>/`

## Complexity
| Algorithm | Time | Space |
|---|---|---|
| Brute force | exponential (Θ(4ⁿ/√n) calls) | O(m+n) |
| LCS / Needleman–Wunsch DP | Θ(mn) | Θ(mn) |
| Hirschberg | Θ(mn) | Θ(n) |
