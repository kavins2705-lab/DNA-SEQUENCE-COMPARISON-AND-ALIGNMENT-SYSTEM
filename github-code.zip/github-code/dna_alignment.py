"""
DNA Sequence Comparison and Alignment System
Design and Analysis of Algorithms - Project
Author: Kavin S (711525BCS069), II-CSE-A, KIT - Kalaignarkarunanidhi Institute of Technology

Algorithms implemented
  1. Brute-force recursion for LCS            (exponential time)
  2. LCS by dynamic programming + traceback   (Theta(mn) time, Theta(mn) space)
  3. Needleman-Wunsch global alignment        (Theta(mn) time, Theta(mn) space)
  4. Hirschberg linear-space LCS              (Theta(mn) time, Theta(n) space)

Run:  python dna_alignment.py
"""
import random
import sys
import time

sys.setrecursionlimit(10000)


# ---------------------------------------------------------------- brute force
def lcs_bruteforce(x, y):
    """Plain recursion on suffix pairs. Returns LCS length only."""
    def rec(i, j):
        if i == len(x) or j == len(y):
            return 0
        if x[i] == y[j]:
            return 1 + rec(i + 1, j + 1)
        return max(rec(i + 1, j), rec(i, j + 1))
    return rec(0, 0)


# ------------------------------------------------------------------- LCS (DP)
def lcs(x, y):
    m, n = len(x), len(y)
    L = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if x[i - 1] == y[j - 1]:
                L[i][j] = L[i - 1][j - 1] + 1
            else:
                L[i][j] = max(L[i - 1][j], L[i][j - 1])
    out, i, j = [], m, n
    while i > 0 and j > 0:
        if x[i - 1] == y[j - 1]:
            out.append(x[i - 1]); i -= 1; j -= 1
        elif L[i - 1][j] >= L[i][j - 1]:
            i -= 1
        else:
            j -= 1
    return L[m][n], "".join(reversed(out))


# ------------------------------------------------------- Needleman-Wunsch
def needleman_wunsch(x, y, match=1, mismatch=-1, gap=-2):
    m, n = len(x), len(y)
    S = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(1, m + 1):
        S[i][0] = i * gap
    for j in range(1, n + 1):
        S[0][j] = j * gap
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            d = S[i-1][j-1] + (match if x[i-1] == y[j-1] else mismatch)
            S[i][j] = max(d, S[i-1][j] + gap, S[i][j-1] + gap)
    a, b, i, j = [], [], m, n
    while i > 0 or j > 0:
        if i > 0 and j > 0 and S[i][j] == S[i-1][j-1] + (match if x[i-1] == y[j-1] else mismatch):
            a.append(x[i-1]); b.append(y[j-1]); i -= 1; j -= 1
        elif i > 0 and S[i][j] == S[i-1][j] + gap:
            a.append(x[i-1]); b.append("-"); i -= 1
        else:
            a.append("-"); b.append(y[j-1]); j -= 1
    return S[m][n], "".join(reversed(a)), "".join(reversed(b))


# ------------------------------------------------------------- Hirschberg
def last_row(x, y):
    """Last row of the LCS table using only two rows (linear space)."""
    prev = [0] * (len(y) + 1)
    for c in x:
        cur = [0] * (len(y) + 1)
        for j in range(1, len(y) + 1):
            if c == y[j - 1]:
                cur[j] = prev[j - 1] + 1
            else:
                cur[j] = max(prev[j], cur[j - 1])
        prev = cur
    return prev


def hirschberg(x, y):
    """Returns one LCS string using linear working memory."""
    if not x or not y:
        return ""
    if len(x) == 1:
        return x if x in y else ""
    mid = len(x) // 2
    n = len(y)
    l1 = last_row(x[:mid], y)
    l2 = last_row(x[mid:][::-1], y[::-1])
    k = max(range(n + 1), key=lambda j: l1[j] + l2[n - j])
    return hirschberg(x[:mid], y[:k]) + hirschberg(x[mid:], y[k:])


# ----------------------------------------------------------------- driver
def timed(fn, *args):
    t = time.perf_counter()
    r = fn(*args)
    return r, (time.perf_counter() - t) * 1000


def random_dna(n, rng):
    return "".join(rng.choice("ACGT") for _ in range(n))


def main():
    rng = random.Random(7)
    tests = [
        ("1. Classic textbook pair", "ACCGGTCGAGTGCGCGGAAGCCGGCCGAA", "GTCGTTCGGAATGCCGTTGCTCTGTAAA"),
        ("2. Identical sequences", "ACGTACGT", "ACGTACGT"),
        ("3. No common base", "AAAAAA", "TTTTTT"),
        ("4. Short mutated pair", "GATTACA", "GCATGCT"),
        ("5. Random 1000-base pair (seed 7)", random_dna(1000, rng), random_dna(1000, rng)),
    ]
    line = "=" * 72
    print(line)
    print(" DNA SEQUENCE COMPARISON AND ALIGNMENT SYSTEM")
    print(" Scoring: match = +1, mismatch = -1, gap = -2")
    print(line)

    for name, x, y in tests:
        print(f"\nTest {name}   [{len(x)} x {len(y)}]")
        show = len(x) <= 40
        if show:
            print("  X =", x)
            print("  Y =", y)
        (length, seq), t_dp = timed(lcs, x, y)
        (score, a, b), t_nw = timed(needleman_wunsch, x, y)
        h_seq, t_h = timed(hirschberg, x, y)
        print(f"  LCS (DP)         : length {length}" + (f"  ->  {seq}" if show else "") + f"   [{t_dp:.2f} ms]")
        print(f"  LCS (Hirschberg) : length {len(h_seq)}" + (f"  ->  {h_seq}" if show else "") + f"   [{t_h:.2f} ms]")
        print(f"  Lengths agree    : {len(h_seq) == length}")
        print(f"  Alignment score  : {score}   [{t_nw:.2f} ms]")
        if show:
            mid = "".join("|" if p == q else (" " if "-" in (p, q) else "x") for p, q in zip(a, b))
            print("    " + a)
            print("    " + mid)
            print("    " + b)

    print("\n" + line)
    print(" Brute-force recursion vs DP  (prefixes of test case 1)")
    print(line)
    x, y = tests[0][1], tests[0][2]
    print(f"  {'prefix':>6} | {'recursion (ms)':>15} | {'DP (ms)':>10} | LCS")
    for p in (8, 10, 12, 14, 16):
        r, t_r = timed(lcs_bruteforce, x[:p], y[:p])
        (l, _), t_d = timed(lcs, x[:p], y[:p])
        print(f"  {p:>6} | {t_r:>15.2f} | {t_d:>10.3f} | {r}")
    print("\nRecursion time grows ~4x per 2 extra characters (exponential);")
    print("DP stays Theta(mn).")


if __name__ == "__main__":
    main()
